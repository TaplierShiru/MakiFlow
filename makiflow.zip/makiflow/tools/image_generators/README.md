# Example

```python
from makiflow.generators import ImageFactory

if __name__ == '__main__':
    factory = ImageFactory(270, 110, 25, 'result')
    factory.run_threads()
``````

_Will be soon..._

